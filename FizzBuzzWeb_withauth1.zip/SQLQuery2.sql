﻿drop procedure sp_numberRemove
Go
CREATE PROCEDURE [dbo].[sp_numberRemove]
@id int
AS
Delete FROM Fizzbuzz where id = @id
