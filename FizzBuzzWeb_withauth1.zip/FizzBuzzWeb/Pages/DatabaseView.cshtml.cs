using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using FizzBuzzWeb.Models;
using FizzBuzzWeb.Data;
using Microsoft.Extensions.Logging;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;

namespace FizzBuzzWeb.Pages
{
    [Authorize]
    public class DatabaseViewModel : PageModel
    {
        
        private readonly FizzbuzzContext _context;
        public IConfiguration _configuration { get; }
        public IList<Fizbuzz> Fizzbuzzlist { get; set; }
        public DatabaseViewModel(FizzbuzzContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public List<Fizbuzz> session = new List<Fizbuzz>();
        public void OnGet()
        {        
            Fizzbuzzlist = _context.Fizzbuzz.ToList();
            var SessionAddress = HttpContext.Session.GetString("SessionAddress");
            if (SessionAddress != null)
            {
                session = JsonConvert.DeserializeObject<List<Fizbuzz>>(SessionAddress);
            }
        }
        public IActionResult OnPost(int value)
        {
            string FizzBuzzDB_connection_string = _configuration.GetConnectionString("FizzBuzzDB"); //database fun           
            SqlConnection con = new SqlConnection(FizzBuzzDB_connection_string);            
            SqlCommand rem = new SqlCommand("sp_numberRemove", con); // using SQLQuery2.sql
            rem.CommandType = CommandType.StoredProcedure;
            SqlParameter idparam = new SqlParameter("@id", SqlDbType.Int);
            idparam.Value = value;
            rem.Parameters.Add(idparam);
            con.Open(); //running the query
            int numAff = rem.ExecuteNonQuery();
            con.Close();  

            return RedirectToPage("./DatabaseView");
        }
    }
}
