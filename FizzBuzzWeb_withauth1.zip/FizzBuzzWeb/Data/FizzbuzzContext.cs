﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FizzBuzzWeb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace FizzBuzzWeb.Data
{
    
    public class FizzbuzzContext:DbContext // context class
    {
        public FizzbuzzContext(DbContextOptions options) : base(options) { }
        public DbSet<Fizbuzz> Fizzbuzz { get; set; }
    }
}
