using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using FizzBuzzWeb.Models;
namespace FizzBuzzWeb.Pages
{
    public class Ostatnio_SzukaneModel : PageModel

    {
        public List<Fizbuzz> session = new List<Fizbuzz>();
   
        public void OnGet()
        {
            var SessionAddress = HttpContext.Session.GetString("SessionAddress");        
            if (SessionAddress != null)
            {                  
               session = JsonConvert.DeserializeObject<List<Fizbuzz>>(SessionAddress);
            }
        }
    }
}
