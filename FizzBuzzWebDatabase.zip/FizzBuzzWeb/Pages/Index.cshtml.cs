﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FizzBuzzWeb.Models;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.Extensions.Configuration;

namespace FizzBuzzWeb.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        public IConfiguration _configuration { get; }
        public string lblInfoText;    
        public List<Fizbuzz> session;
        public string error1 = "wartosc: ";
        public string error2 = "nie spełnia warunków zadania";

        public IndexModel(ILogger<IndexModel> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public void OnGet()
        {
            var SessionAddress = HttpContext.Session.GetString("SessionAddress");
            if (SessionAddress != null)
            {
                session = JsonConvert.DeserializeObject<List<Fizbuzz>>(SessionAddress);
            }
            else
                session = new List<Fizbuzz>();
        }
        public IActionResult OnPost(int number)
        {

            OnGet();          
            Fizbuzz fizzbuzz = new Fizbuzz();
            fizzbuzz.Number = number;
            fizzbuzz.output();
            session.Add(fizzbuzz);
            if (ModelState.IsValid)
            {
                HttpContext.Session.SetString("SessionAddress",
                JsonConvert.SerializeObject(session));

                if (fizzbuzz.FizzBuzz == "Fizz" || fizzbuzz.FizzBuzz == "Buzz" || fizzbuzz.FizzBuzz == "FizzBuzz")
                {
                    string myCompanyDB_connection_string = _configuration.GetConnectionString("FizzBuzzDB"); //database fun 
                    SqlConnection con = new SqlConnection(myCompanyDB_connection_string); //creating the connection parameter
                    SqlCommand cmd = new SqlCommand("sp_numberAdd", con); //creating an sql command using SQLQuery1.sql
                    cmd.CommandType = CommandType.StoredProcedure; // specifies that the procedure is stored
                    SqlParameter nr = new SqlParameter("@Number", SqlDbType.Int);
                    nr.Value = fizzbuzz.Number;
                    SqlParameter rs = new SqlParameter("@result", SqlDbType.VarChar, 50);
                    rs.Value = fizzbuzz.FizzBuzz;
                    SqlParameter idparam = new SqlParameter("@id", SqlDbType.Int);
                    idparam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(nr); //adding sql variables to query
                    cmd.Parameters.Add(rs);
                    cmd.Parameters.Add(idparam);
                    con.Open(); //executing the query
                    int numAff = cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            return Page();
        }

        
    }
}
