﻿drop procedure sp_numberAdd
GO
CREATE PROCEDURE [dbo].[sp_numberAdd]
@id int output,
@Number int,
@result varchar(50)
AS
INSERT INTO Fizzbuzz (Number, result) VALUES (@Number, @result)
SET @id = @@IDENTITY